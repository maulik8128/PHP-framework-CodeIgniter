<?php 



class User_model extends CI_model {


	public function get_users() {



		
	}




	
}








 ?>